import React from "react";

function TailwindSection() {
  return (
    <div>
    <p className="uppercase text-center text-custom-blue-300 font-semibold md:text-2xl lg:text-xl xl:text-2xl 2xl:text-3xl mb-2 px-4">
        A Digital solution for the management
      </p>
    </div>
  );
}

export default TailwindSection;
